import UIKit

class Algorithm {
  var description = ""
}
