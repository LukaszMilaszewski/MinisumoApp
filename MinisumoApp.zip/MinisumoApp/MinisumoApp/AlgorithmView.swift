import UIKit

class AlgorithmView: UIView {
  

    @IBOutlet weak var descriptionLabel: UILabel!
}
